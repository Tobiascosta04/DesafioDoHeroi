
import entidades.Heroi;

public class App {
    public static void main(String[] args) throws Exception {
        Heroi heroi = new Heroi("Tobyas", 9020);
        heroi.exibirHeroi();
    }
}
